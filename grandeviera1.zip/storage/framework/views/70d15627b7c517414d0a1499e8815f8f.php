<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grandeviera</title>

    <!--Favicon Logo Web-->
    <link rel="shortcut icon" href="./assets/icon/nm.png" type="image/x-icon"/>

    <!--CSS-->
    <link rel="stylesheet" href="./dist/CSS/c-ourhousedetails.css"/>
    <link rel="stylesheet" href="./dist/partials/navbarandfooter.css"/>

    <!--Jonsuh Hamburger-->
    <link rel="stylesheet" href="./dist/CSS/hamburgers.css"/>

    <!--Font Poppins-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"/>

    <!--Font Awsome CDN-->
    <link 
        rel="stylesheet" 
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" 
        integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" 
        crossorigin="anonymous" 
        referrerpolicy="no-referrer" 
    />

    <!--AOS Motion-->
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
</head>

<body id="ourhousedetails-page">

    <!-- Header -->
    <?php echo csrf_field(); ?>
    <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Header -->

    <!--Our House Details-->
    <div class="section-our-house-details">
        <div class="container-page">
            <div class="container-scene" data-aos="fade-up" data-aos-duration="1000">
                <div class="slider">
                    <img src="./assets/images/imgrandom-1.jpg" alt="Image 1">
                </div>
                <div class="container-info">
                    <h2>Kemang</h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore, quasi minima! Alias, odio.</p>
                    <div class="three-buttons">
                        <div class="btn-agent">
                            <h4>Raina</h4> 
                            <p>rainamahira@gmail.com</p>
                        </div>
                        <button class="btn-wa" onclick="window.location.href='https://wa.me/6285215819629'">wa</button>
                        <button class="btn-favorite">Fav</button>
                    </div>
                </div>
            </div>
            <div class="container-long-details" data-aos="fade-up" data-aos-delay="300" data-aos-duration="1000">
                <div class="container-description">
                    <h3>Description</h3>
                    <p style="text-align: left;">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Excepturi quae numquam nemo rem ex, repudiandae quaerat aspernatur incidunt. Unde eum asperiores aliquid aliquam incidunt veniam tenetur ullam praesentium possimus modi. <br>
                        1. a <br>
                        2. b <br>
                        3. c <br>
                    </p>
                </div>
                <div class="container-location">
                    <h3>Location</h3>
                    <p style="text-align: left;">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique, neque. Aspernatur modi nihil nulla ex quaerat ea vero ducimus aliquid. Quis enim hic nisi asperiores minus, consectetur culpa? Repudiandae, dignissimos. <br>
                        1. a <br>
                        2. b <br>
                        3. c <br>
                    </p>
                </div>
            </div>                                                                            
        </div>                
    </div>
    <!--Our House Details-->

    <!-- Footer -->
    <div id="footer-container"></div>
    <script>
        fetch('./dist/partials/footer.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById('footer-container').innerHTML = data;
            })
            .catch(error => console.error('Error loading footer:', error));
    </script>
    <!-- Footer -->
  
    <!--JS Home Page-->
    <script src="./dist/JavaScript/javascript.js"></script>
    
    <!-- JavaScript untuk Slick Carousel -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    
    <!-- JavaScript untuk Slick Carousel (kalo gambar yg diupload banyak) -->
    <script>
        $(document).ready(function(){
            $('.slider').slick({
                slidesToShow: 1,
                slidesToScroll: 1,
                arrows: true,
                fade: true,
                asNavFor: '.container-info',
            });
        });
    </script>

    <!--AOS Motion-->
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script>
      AOS.init();
    </script>

</body>
</html><?php /**PATH D:\grandeviera trial\resources\views/c-ourhousedetails.blade.php ENDPATH**/ ?>