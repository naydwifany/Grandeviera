<?php

declare(strict_types=1);

namespace Carbon\Doctrine;

class CarbonImmutableType extends DateTimeImmutableType implements CarbonDoctrineType
{
}
